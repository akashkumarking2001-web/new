module.exports = {
  tailwind: {
    config: './src/tailwind.js',
    format: 'auto',
  },
};
