import type { ServerConfig } from '../src/types/settings.js';

export function ensureHooksInstalled(config: ServerConfig): void;
