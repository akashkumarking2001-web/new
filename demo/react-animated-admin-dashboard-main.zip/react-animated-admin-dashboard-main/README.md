# react-animated-admin-dashboard

  React Animated Admin Dashboard And Login Page

# Video tutorial

[https://youtu.be/CWpTAzOz6mE](https://youtu.be/CWpTAzOz6mE)<br>

# Resource

[Create React App](https://create-react-app.dev/)<br>
[Material UI](https://create-react-app.dev/)<br>
[React Router](https://reactrouter.com/)<br>
[React Chart JS](https://react-chartjs-2.js.org/)<br>
[Images](https://www.freepik.com/)<br>
[Images](https://free3dicon.com/)<br>

# Preview

![dashboard-page](https://github.com/trananhtuat/react-animated-admin-dashboard/assets/67447840/a97868d0-70f5-47c2-a50a-a5024dcc6822)

![login-page](https://github.com/trananhtuat/react-animated-admin-dashboard/assets/67447840/68c43cc2-09b3-44db-bbb9-1ec2b3d52c31)
