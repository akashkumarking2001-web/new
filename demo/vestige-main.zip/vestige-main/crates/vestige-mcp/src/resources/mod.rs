//! MCP Resources
//!
//! Resource implementations for the Vestige MCP server.

pub mod codebase;
pub mod memory;
