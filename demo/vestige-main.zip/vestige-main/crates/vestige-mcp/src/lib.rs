//! Vestige MCP Server Library
//!
//! Shared modules accessible to all binaries in the crate.

pub mod cognitive;
pub mod dashboard;
